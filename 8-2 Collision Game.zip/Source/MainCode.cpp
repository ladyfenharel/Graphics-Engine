#include <GLFW/glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <vector>
#include <windows.h>
#include <time.h>
#include <cmath> // Include cmath for mathematical functions

using namespace std;

const float DEG2RAD = 3.14159 / 180;
const int MAX_HITS = 50;
const int MAX_CIRCLES = 10;
const int NUM_BRICK_ROWS = 5;
const int NUM_BRICK_COLS = 10;

void processInput(GLFWwindow* window);

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

template <typename T>
T clamp(T value, T minVal, T maxVal) {
    return (value < minVal) ? minVal : (value > maxVal) ? maxVal : value;
}

class Paddle {
public:
    float x, y, width, height;
    const float paddleSpeed = 0.02f;
    float red, green, blue;

    Paddle(float xx, float yy, float w, float h, float r, float g, float b)
        : x(xx), y(yy), width(w), height(h), red(r), green(g), blue(b) {
    }

    void movePaddle(GLFWwindow* window) {
        if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {
            if (x - width / 2 > -1)
                x -= paddleSpeed;
        }
        if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {
            if (x + width / 2 < 1)
                x += paddleSpeed;
        }
    }

    void drawPaddle() {
        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        glVertex2f(x - width / 2, y - height / 2);
        glVertex2f(x + width / 2, y - height / 2);
        glVertex2f(x + width / 2, y + height / 2);
        glVertex2f(x - width / 2, y + height / 2);
        glEnd();
    }
};

class Brick {
public:
    float red, green, blue;
    float x, y, width, height; // Added height for rectangular bricks
    BRICKTYPE brick_type;
    ONOFF onoff;
    int hitCount;

    Brick(BRICKTYPE bt, float xx, float yy, float ww, float hh, float rr, float gg, float bb) {
        brick_type = bt; x = xx; y = yy; width = ww; height = hh;
        red = rr; green = gg; blue = bb;
        onoff = ON;
        hitCount = 0;
    }

    void drawBrick() {
        if (onoff == OFF) {
            return;
        }

        double halfWidth = width / 2;
        double halfHeight = height / 2;

        // Dynamically adjust the color based on hitCount
        float adjustedRed = max(0.0f, red - hitCount * 0.1f);
        float adjustedGreen = max(0.0f, green - hitCount * 0.1f);
        float adjustedBlue = max(0.0f, blue - hitCount * 0.1f);

        glColor3d(adjustedRed, adjustedGreen, adjustedBlue);

        glBegin(GL_POLYGON);
        glVertex2d(x + halfWidth, y + halfHeight);
        glVertex2d(x + halfWidth, y - halfHeight);
        glVertex2d(x - halfWidth, y - halfHeight);
        glVertex2d(x - halfWidth, y + halfHeight);
        glEnd();
    }
};

class Circle {
public:
    float red, green, blue;
    float radius;
    float x;
    float y;
    float speed = 0.02;
    const float maxSpeed = 0.025;
    const float minSpeed = 0.008;
    float vx, vy;

    Circle(double xx, double yy, double rr, float r, float g, float b) {
        x = xx;
        y = yy;
        radius = clamp(rr, 0.01, 0.03);

        vx = speed * (rand() % 2 == 0 ? 1 : -1);
        vy = speed * (rand() % 2 == 0 ? 1 : -1);

        red = r;
        green = g;
        blue = b;
    }

    void CheckCollision(Brick* brk, Paddle* paddle) {
        if (brk->onoff == OFF) {
            return;
        }

        double halfWidth = brk->width / 2;
        double halfHeight = brk->height / 2; // Use halfHeight for collision

        if (brk->brick_type == REFLECTIVE) {
            if ((x > brk->x - halfWidth && x <= brk->x + halfWidth) &&
                (y > brk->y - halfHeight && y <= brk->y + halfHeight)) {

                // *** DEBUGGING: Print brick state before collision ***
                cout << "Collision with REFLECTIVE brick at (" << brk->x << ", " << brk->y << ")" << endl;
                cout << "Brick state: onoff = " << brk->onoff << ", hitCount = " << brk->hitCount << endl;

                vx = -vx + ((rand() % 5) / 100.0f - 0.05f);
                vy = -vy + ((rand() % 5) / 100.0f - 0.05f);

                if (abs(vx) > maxSpeed) vx = maxSpeed * (vx > 0 ? 1 : -1);
                if (abs(vy) > maxSpeed) vy = maxSpeed * (vy > 0 ? 1 : -1);

                brk->red = max(0.0f, brk->red - 0.1f);
                brk->green = min(1.0f, brk->green + 0.1f);
                brk->blue = max(0.0f, brk->blue - 0.1f);

                brk->hitCount++;
                if (brk->hitCount >= MAX_HITS) {
                    brk->onoff = OFF;

                    // *** DEBUGGING: Print message when brick is turned off ***
                    cout << "REFLECTIVE brick at (" << brk->x << ", " << brk->y << ") turned OFF" << endl;
                }
            }
        }
        else if (brk->brick_type == DESTRUCTABLE) {
            if ((x > brk->x - halfWidth && x <= brk->x + halfWidth) &&
                (y > brk->y - halfHeight && y <= brk->y + halfHeight)) {

                // *** DEBUGGING: Print brick state before collision ***
                cout << "Collision with DESTRUCTABLE brick at (" << brk->x << ", " << brk->y << ")" << endl;
                cout << "Brick state: onoff = " << brk->onoff << ", hitCount = " << brk->hitCount << endl;

                brk->onoff = OFF;
                // *** DEBUGGING: Print message when brick is turned off ***
                cout << "DESTRUCTABLE brick at (" << brk->x << ", " << brk->y << ") turned OFF" << endl;
            }
        }

        if (y - radius <= paddle->y + paddle->height / 2 && y + radius >= paddle->y - paddle->height / 2) {
            if (x - radius <= paddle->x + paddle->width / 2 && x + radius >= paddle->x - paddle->width / 2) {
                if (vy < 0) {
                    vy = -vy;
                    vx += (rand() % 20) / 100.0f - 0.1f;
                    y = paddle->y + paddle->height / 2 + radius;
                }
            }
        }
    }

    void MoveOneStep() {
        x += vx;
        y += vy;

        if (x - radius <= -1.0f || x + radius >= 1.0f) {
            vx = -vx;
            x = clamp(x, -1.0f + radius, 1.0f - radius);
        }

        if (y - radius <= -1.0f || y + radius >= 1.0f) {
            vy = -vy;
            y = clamp(y, -1.0f + radius, 1.0f - radius);
        }
    }

    void DrawCircle() {
        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        for (int i = 0; i < 360; i++) {
            float degInRad = i * DEG2RAD;
            glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
        }
        glEnd();
    }
};

vector<Circle> world;
vector<Brick> bricks; // Use a vector to store bricks

int main(void) {
    srand(time(NULL));

    if (!glfwInit()) {
        exit(EXIT_FAILURE);
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    GLFWwindow* window = glfwCreateWindow(800, 800, "8-2 Assignment", NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    Paddle paddle(0, -0.8, 0.4, 0.05, 1, 1, 1);

    // Create bricks with a nested loop and varying properties
    for (int row = 0; row < NUM_BRICK_ROWS; ++row) {
        for (int col = 0; col < NUM_BRICK_COLS; ++col) {
            float x = -0.8f + col * 0.18f; // Calculate x position
            float y = 0.7f - row * 0.15f; // Calculate y position
            float width = 0.15f;
            float height = 0.1f;
            BRICKTYPE type = (rand() % 2 == 0) ? REFLECTIVE : DESTRUCTABLE;
            float r = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
            float g = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
            float b = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);

            bricks.push_back(Brick(type, x, y, width, height, r, g, b));
        }
    }

    while (!glfwWindowShouldClose(window)) {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float)height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);

        processInput(window);
        paddle.movePaddle(window);

        for (int i = 0; i < world.size(); i++) {
            // Check collisions with all bricks in the vector
            for (auto& brick : bricks) {
                world[i].CheckCollision(&brick, &paddle);
            }
            world[i].MoveOneStep();
            world[i].DrawCircle();
        }

        // Draw all bricks in the vector
        for (auto& brick : bricks) {
            brick.drawBrick();
        }

        paddle.drawPaddle();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}

void processInput(GLFWwindow* window) {
    float currentTime = glfwGetTime();
    static float lastCircleTime = 0.0f;
    const float cooldownTime = 0.5f;

    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS &&
        world.size() < MAX_CIRCLES &&
        (currentTime - lastCircleTime) >= cooldownTime) {

        lastCircleTime = currentTime;

        double r, g, b;
        r = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
        g = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
        b = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);

        float radius = 0.1f;
        float vx = 0.02f * (rand() % 2 == 0 ? 1 : -1);
        float vy = 0.02f * (rand() % 2 == 0 ? 1 : -1);

        bool overlap;
        float new_x, new_y;

        do {
            overlap = false;
            new_x = static_cast<float>(rand()) / static_cast<float>(RAND_MAX) * 2.0f - 1.0f;
            new_y = static_cast<float>(rand()) / static_cast<float>(RAND_MAX) * 2.0f - 1.0f;

            for (const auto& existingCircle : world) {
                float dx = new_x - existingCircle.x;
                float dy = new_y - existingCircle.y;
                float distance = sqrt(dx * dx + dy * dy);
                if (distance < (radius + existingCircle.radius)) {
                    overlap = true;
                    break;
                }
            }
        } while (overlap);

        Circle newCircle(new_x, new_y, radius, r, g, b);
        world.push_back(newCircle);
    }
}